# JARVIS

A voice-controlled AI assistant that reads your own files (as a graph you
can see) and talks like you want it to. Python standard library only on
the server, vanilla JS in the browser. No frameworks, no build step, no
package manager.

**Status:** steps 1–3 done (index, graph UI, tools + conversation).
Voice (step 4) and the memory/guardrails pass (step 5) aren't built yet —
see "What's not done" below.

---

## Setup

You need Python 3.9+ and nothing else installed. No `npm install`, no
`pip install`, no framework.

```bash
cd jarvis
cp .env.example .env
chmod 600 .env
```

Open `.env` and add your own keys:

```
OPENAI_API_KEY=sk-...       # for real conversation + tool routing
ELEVENLABS_API_KEY=...      # for voice — not wired up yet (step 4)
```

**Never commit `.env` or paste a key into a chat/issue/PR.** If a key
has ever been pasted somewhere it shouldn't (a chat, a public repo),
rotate it immediately in the provider's dashboard — don't just delete
the message.

Generate the demo data once (fixed random seed, so it's identical every
time — the `data/demo_vault/` folder itself isn't checked in):

```bash
python3 data/generate_demo.py
```

Run it:

```bash
python3 agent/main.py
```

Open **http://localhost:8420**.

Without `OPENAI_API_KEY` set, JARVIS still runs — it falls back to
keyword-only routing (search your files, brief you, plan your day,
remember something) and shows a banner saying no model is connected.
It never fails silently.

---

## Access from your phone

This is built to run on a computer — real folders, a real Python
install — and be *viewed* from a phone, not installed on one. The UI is
already touch/mobile-responsive for exactly this.

1. Make sure your phone and computer are on the **same WiFi network**.
2. In `.env`, set:
   ```
   JARVIS_HOST=0.0.0.0
   ```
   This opens the server to your whole local network, not just this
   machine — only do it on WiFi you trust, since it has no login of its
   own (whoever's on the network can reach it).
3. Run `python3 agent/main.py` as usual. It prints a line like:
   ```
   [jarvis] also reachable on your WiFi at http://192.168.1.42:8420 — that's the URL for your phone
   ```
4. Open that exact URL in your phone's browser.

If it doesn't load: your computer's firewall may be blocking incoming
connections on port 8420 — allow it for Python, or temporarily disable
the firewall to confirm that's the cause. Corporate/guest WiFi networks
often block device-to-device traffic entirely (this won't work on those,
by design, on their end).

**Running Python directly on the phone instead** (skipping the computer
entirely) only really works on Android, via [Termux](https://termux.dev/):
install Termux, `pkg install python`, transfer this folder to the phone,
`python data/generate_demo.py && python agent/main.py`, then open
`localhost:8420` in the phone's own browser. There's no equivalent on
iOS (no real terminal/Python environment without heavier workarounds).
Note this only gets you demo mode either way — your real client folders
live on your computer, not your phone.

---

## Running it on your phone

JARVIS itself has to run somewhere with a full Python 3 install — that's
not your phone's browser, it's the server in `agent/main.py`. Two ways
to actually use it from a phone:

**A — run it on your computer, open it from your phone (recommended).**
The server binds to `0.0.0.0` by default, so any device on the same
Wi-Fi can reach it. Find your computer's LAN IP (`ipconfig getifaddr en0`
on Mac, `ipconfig` on Windows, `hostname -I` on Linux) and open
`http://<that-ip>:8420` in your phone's browser. The UI already has a
mobile layout (bottom-sheet inspector, scrollable filter strip, touch +
pinch-zoom on the graph). Your computer's firewall may need to allow
incoming connections on port 8420 the first time.

This exposes the server to your whole local network with no login —
fine on a trusted home Wi-Fi, not something to port-forward onto the
open internet without adding auth first. Set `JARVIS_HOST=127.0.0.1` in
`.env` to go back to localhost-only if you don't need phone access.

**B — run it directly on an Android phone, via Termux.** No computer
needed. Not possible on iOS the same way — iOS doesn't allow a
general-purpose background Python process serving a local port the way
Android's Termux does.

```
# Install Termux from F-Droid (not the outdated Play Store version)
pkg update && pkg install python unzip
# transfer jarvis.zip to your phone (e.g. via a file-sharing app), then:
unzip jarvis.zip && cd jarvis
cp .env.example .env
python3 data/generate_demo.py
python3 agent/main.py
# open http://localhost:8420 in the phone's browser
```

## The demo switch

One environment variable, read in exactly one file (`agent/data.py`):

| `JARVIS_DEMO` | Behavior |
|---|---|
| `1` (default) | Fixtures shaped like a small agency — 9 clients, projects, calls, invoices, proposals, SOPs. Safe to screen-record. `read_inbox` and `brief_me` use fake calendar/inbox data. |
| `0` | Your real folders, listed in `VAULT_PATHS_REAL` inside `agent/data.py`. `read_inbox`/`brief_me` will raise a clear error until real email/calendar integrations are built — they don't pretend to work. |

You have to opt **in** to your real life:

```bash
# in .env
JARVIS_DEMO=0
```

...and add your real folder paths to `VAULT_PATHS_REAL` in `agent/data.py`
first, or it refuses to start with a clear error rather than silently
falling back to demo data.

---

## What it costs

Nothing is metered by JARVIS itself — you pay your API providers
directly, at their prices, only for what you use:

- **OpenAI** (`gpt-4o-mini` by default, set via `OPENAI_MODEL` env var) —
  charged per token, on your OpenAI account. A typical back-and-forth
  costs a fraction of a cent. Check current pricing at
  platform.openai.com/pricing before heavy use.
- **ElevenLabs** (voice, step 4, not built yet) — free tier covers light
  use; beyond that it's metered per character of speech generated and
  per minute transcribed. Check elevenlabs.io/pricing.

JARVIS never calls a paid API without you having put a key in `.env`
yourself, and the system prompt's guardrails explicitly forbid spending
money or calling a paid API without asking first — that's about
*actions* (nothing auto-sends anything), not the base cost of you
talking to it, which is unavoidable and yours to watch.

---

## Project structure

```
jarvis/
├── agent/
│   ├── main.py       HTTP server + API (stdlib http.server, no deps)
│   ├── vault.py       folders → searchable graph (wikilinks = edges)
│   ├── tools.py       the six tools (search_brain, research_web,
│   │                  read_inbox, brief_me, remember, plan_day)
│   ├── data.py         THE ONLY FILE THAT TOUCHES YOUR REAL DATA
│   ├── llm.py          stdlib OpenAI client (urllib, no `openai` package)
│   ├── memory.py       the only file that writes anything, and only to memory/
│   └── prompt.md        the system prompt
├── ui/                  index.html, app.js, graph.js, styles.css
├── data/
│   ├── generate_demo.py    builds data/demo_vault/ with a fixed seed
│   └── demo_vault/         generated — not checked in, regenerate as above
├── memory/               one markdown file per remembered fact
├── CLAUDE.md             who you are — loaded every session (fill this in)
├── .env                  your keys — gitignored, chmod 600 (create from .env.example)
├── .env.example          template, no real keys
└── README.md             this file
```

---

## What's not done yet

- **Voice (step 4).** No ElevenLabs wiring yet — mic/mute buttons show
  "isn't wired up yet" rather than doing nothing.
- **Real email/calendar integration.** `read_inbox` and `brief_me` only
  work in demo mode; real mode needs OAuth that hasn't been built.
- **Real web search for `research_web`.** It currently answers from the
  model's general knowledge, not a live search — no search API key is
  wired up. It says so in every response ("not a live web fetch").
- **Per-type filter toggles** in the UI show live counts but don't yet
  hide/show nodes on the graph — cosmetic only right now.
- **`CLAUDE.md` and `agent/data.py`'s `BUSINESS` dict are placeholders.**
  Fill in your real business, pricing, clients and speaking-style
  preferences before this says anything useful in a real conversation.

## Guardrails (already enforced)

- Never sends anything — drafts and waits.
- Never writes outside `memory/` — everything else is read-only.
- Never writes to memory silently — every `remember` call says exactly
  what got written.
- Never invents a number, date, filename, or client not actually in your
  files — `search_brain` and friends only ever cite real matches.
- Routing works without a model — see the demo switch section above.
