"""
tools.py — the six tools. Every function returns:

    {"speak": "<one or two spoken sentences>", "card": {...}}

speak and card are never the same text — speak is the takeaway, card is
the detail. Nothing here invents a number, date, filename or client that
isn't actually in the vault, memory/, or the demo fixtures in data.py.
"""
import datetime
import os

import data
import memory
import vault


# ---------------------------------------------------------------- schemas --
# OpenAI function-calling tool schemas. Kept next to the implementations so
# they can't drift apart.
TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "search_brain",
            "description": "Find a specific fact from the user's own indexed files (clients, "
                            "projects, invoices, notes, etc). Use for anything that should be "
                            "answerable from their own vault, not general knowledge.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string", "description": "What to search for."}},
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "research_web",
            "description": "Look something up that ISN'T in the user's own files — a price, a "
                            "competitor, a fact about the outside world — and relate it back to "
                            "their own numbers.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string"}},
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_inbox",
            "description": "Check unread messages: who wrote, what about, and whether they "
                            "already exist as a Person/Client in the vault.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "brief_me",
            "description": "Today's calendar, unread count, and anything that slipped "
                            "(overdue invoices, stale proposals).",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "remember",
            "description": "Save one fact that will still matter in three months. Only call "
                            "this when the user actually asks you to remember something, or "
                            "states something clearly durable.",
            "parameters": {
                "type": "object",
                "properties": {"fact": {"type": "string"}},
                "required": ["fact"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "plan_day",
            "description": "Five items max, ordered by what moves money: overdue invoices, "
                            "pending proposals, today's calls, stale projects.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
]


class Tools:
    def __init__(self, nodes):
        self.nodes = nodes

    # -- 1. search_brain --------------------------------------------------
    def search_brain(self, query):
        results = vault.search(self.nodes, query, limit=5)
        if not results:
            return {
                "speak": f"Nothing in your files matches \u201c{query}.\u201d",
                "card": {"tool": "search_brain", "query": query, "results": []},
            }
        top = results[0][0]
        if len(results) == 1:
            speak = f"One match \u2014 {top.title}."
        else:
            names = ", ".join(n.title for n, _ in results[:3])
            speak = f"Found it across {len(results)} files \u2014 {names}."
        return {
            "speak": speak,
            "card": {
                "tool": "search_brain",
                "query": query,
                "results": [
                    {"title": n.title, "type": n.type, "snippet": snip, "path": n.path}
                    for n, snip in results
                ],
            },
        }

    # -- 2. research_web ----------------------------------------------------
    def research_web(self, query, ai_call=None):
        biz = data.get_business()
        if ai_call is None:
            return {
                "speak": "No model wired up, so I can't research that right now.",
                "card": {"tool": "research_web", "query": query, "error": "no model available"},
            }
        prompt = (
            f"The user runs: {biz['business']}. Their offers: {biz['offers']}.\n"
            f"Question: {query}\n"
            "Answer briefly (2-3 sentences), then relate the number back to their "
            "own margin/offer if a price is involved. Say plainly if you're not "
            "certain of a current figure \u2014 don't invent one."
        )
        try:
            answer = ai_call(prompt)
        except Exception as e:
            return {
                "speak": "Couldn't reach the model to research that.",
                "card": {"tool": "research_web", "query": query, "error": str(e)},
            }
        return {
            "speak": answer.strip().split("\n")[0][:200],
            "card": {"tool": "research_web", "query": query, "answer": answer.strip(),
                      "note": "General-knowledge answer, not a live web fetch \u2014 no search API is wired up yet."},
        }

    # -- 3. read_inbox --------------------------------------------------
    def read_inbox(self):
        try:
            inbox = data.get_inbox()
        except RuntimeError as e:
            return {"speak": str(e), "card": {"tool": "read_inbox", "error": str(e)}}

        unread = [m for m in inbox if m["unread"]]
        known_titles = {n.title.lower() for n in self.nodes.values()}
        rows = []
        for m in unread:
            in_vault = m["from"].lower() in known_titles
            rows.append({**m, "known_contact": in_vault})

        if not unread:
            return {"speak": "Inbox is clear.", "card": {"tool": "read_inbox", "messages": []}}

        known_count = sum(1 for r in rows if r["known_contact"])
        speak = f"{len(unread)} unread. {known_count} from people already in your files."
        return {"speak": speak, "card": {"tool": "read_inbox", "messages": rows}}

    # -- 4. brief_me --------------------------------------------------
    def brief_me(self):
        try:
            calendar = data.get_calendar()
            inbox = data.get_inbox()
        except RuntimeError as e:
            return {"speak": str(e), "card": {"tool": "brief_me", "error": str(e)}}

        unread = sum(1 for m in inbox if m["unread"])
        overdue_invoices = [
            n for n in self.nodes.values()
            if n.type == "Invoice" and n.fields.get("status") == "overdue"
        ]

        parts = [f"{len(calendar)} on the calendar", f"{unread} unread"]
        if overdue_invoices:
            parts.append(f"{len(overdue_invoices)} invoice(s) overdue")
        speak = ", ".join(parts) + "."

        return {
            "speak": speak,
            "card": {
                "tool": "brief_me",
                "calendar": calendar,
                "unread_count": unread,
                "overdue_invoices": [{"title": n.title, "path": n.path} for n in overdue_invoices],
            },
        }

    # -- 5. remember --------------------------------------------------
    def remember(self, fact):
        fname, content = memory.remember(fact)
        return {
            "speak": f"Wrote it to memory: {fact.strip()}",
            "card": {"tool": "remember", "file": fname, "content": content},
        }

    # -- 6. plan_day --------------------------------------------------
    def plan_day(self):
        items = []

        for n in self.nodes.values():
            if n.type == "Invoice" and n.fields.get("status") == "overdue":
                items.append((100, f"Chase overdue invoice \u2014 {n.title}", n))
            elif n.type == "Proposal":
                items.append((60, f"Follow up on proposal \u2014 {n.title}", n))

        try:
            calendar = data.get_calendar()
            for c in calendar:
                items.append((80, f"{c['time']} \u2014 {c['title']}", None))
        except RuntimeError:
            pass

        for n in self.nodes.values():
            if n.type == "Project" and n.fields.get("status") == "overdue":
                items.append((50, f"Stalled project \u2014 {n.title}", n))

        items.sort(key=lambda x: -x[0])
        top5 = items[:5]

        if not top5:
            return {"speak": "Nothing flagged \u2014 clean slate.", "card": {"tool": "plan_day", "items": []}}

        speak = f"Top of the list: {top5[0][1]}." if len(top5) == 1 else \
                f"{len(top5)} things, led by {top5[0][1]}."
        return {
            "speak": speak,
            "card": {
                "tool": "plan_day",
                "items": [{"label": label, "path": n.path if n else None} for _, label, n in top5],
            },
        }
