"""
vault.py — folders -> searchable graph.

Read-only. Never writes anything. Walks a list of root folders, indexes
markdown/text/pdf files under a size cap, pulls a `type:` out of YAML-style
frontmatter if present (else infers "Note"), and treats [[wikilinks]] as
edges between files (matched by filename stem, case-insensitive).

Skips: node_modules, .git, any dir starting with '.', files over MAX_BYTES.
"""
import os
import re
import glob

MAX_BYTES = 2 * 1024 * 1024  # 2 MB
SKIP_DIRS = {"node_modules", ".git", "__pycache__", ".venv"}
TEXT_EXTS = {".md", ".markdown", ".txt"}
PDF_EXTS = {".pdf"}

WIKILINK_RE = re.compile(r"\[\[([^\]|#]+)(?:\|[^\]]*)?\]\]")
FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
FIELD_RE = re.compile(r"^(\w+):\s*(.*)$", re.MULTILINE)
H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)


class Node:
    __slots__ = ("id", "path", "title", "type", "body_preview", "body_full",
                 "fields", "links_out", "degree")

    def __init__(self, id_, path, title, type_, body_preview, body_full, fields):
        self.id = id_
        self.path = path
        self.title = title
        self.type = type_
        self.body_preview = body_preview
        self.body_full = body_full    # used for search_brain; not sent to the browser wholesale
        self.fields = fields          # frontmatter fields (status, amount, etc.)
        self.links_out = []  # list of node ids this note links to
        self.degree = 0      # filled in after graph is built


def _slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def _parse_frontmatter(text):
    m = FRONTMATTER_RE.match(text)
    if not m:
        return {}, text
    fm_text = m.group(1)
    fields = dict(FIELD_RE.findall(fm_text))
    body = text[m.end():]
    return fields, body


def _iter_files(roots):
    for root in roots:
        if not os.path.isdir(root):
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
            for fn in filenames:
                ext = os.path.splitext(fn)[1].lower()
                if ext in TEXT_EXTS or ext in PDF_EXTS:
                    full = os.path.join(dirpath, fn)
                    try:
                        if os.path.getsize(full) > MAX_BYTES:
                            continue
                    except OSError:
                        continue
                    yield full, ext


def build_graph(roots):
    """
    roots: list of folder paths to index.
    Returns (nodes: dict[id -> Node], stats: dict)
    """
    nodes = {}
    stem_to_id = {}
    skipped_pdfs = 0

    # Pass 1: read every file, build nodes
    for path, ext in _iter_files(roots):
        stem = os.path.splitext(os.path.basename(path))[0]
        node_id = _slug(stem)

        if ext in PDF_EXTS:
            # No PDF text extraction in the stdlib-only server; index as a
            # node by filename only so it still shows in the graph and can
            # be named in search results, but body is empty.
            fields, body = {}, ""
            skipped_pdfs += 1
        else:
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    text = f.read()
            except OSError:
                continue
            fields, body = _parse_frontmatter(text)

        type_ = fields.get("type", "Note").strip() or "Note"

        # Wikilinks reference the human-readable title (an H1 line, e.g.
        # "# Call — Acme — 2026-03-23"), not the slugified filename — so
        # that's what has to be indexed for link resolution to work.
        h1 = H1_RE.search(body)
        title = h1.group(1).strip() if h1 else stem

        body_after_h1 = body[h1.end():] if h1 else body
        preview_lines = [l for l in body_after_h1.strip().splitlines() if l.strip()]
        preview = preview_lines[0][:200] if preview_lines else ""

        node = Node(node_id, path, title, type_, preview, body_after_h1.strip(), fields)
        nodes[node_id] = node
        stem_to_id[title.lower()] = node_id
        stem_to_id[stem.lower()] = node_id  # fallback for links by filename

        if ext not in PDF_EXTS:
            for link_target in WIKILINK_RE.findall(body):
                node.links_out.append(link_target.strip())  # resolved in pass 2

    # Pass 2: resolve wikilink text -> node ids, compute degree
    edges = []
    for node in nodes.values():
        resolved = []
        for target_text in node.links_out:
            target_id = stem_to_id.get(target_text.strip().lower())
            if target_id and target_id in nodes:
                resolved.append(target_id)
                edges.append((node.id, target_id))
        node.links_out = resolved

    for a, b in edges:
        nodes[a].degree += 1
        nodes[b].degree += 1

    stats = {
        "total_nodes": len(nodes),
        "total_edges": len(edges),
        "skipped_pdfs_no_text": skipped_pdfs,
        "by_type": {},
    }
    for n in nodes.values():
        stats["by_type"][n.type] = stats["by_type"].get(n.type, 0) + 1

    return nodes, stats


def top_hubs(nodes, n=10):
    return sorted(nodes.values(), key=lambda x: x.degree, reverse=True)[:n]


def search(nodes, query, limit=5):
    """
    Dumb-but-honest keyword search over title + body. No embeddings, no
    fuzzy matching — every term in the query must appear somewhere in the
    note for it to match, so what comes back is always traceable to real
    text in a real file (never invented).
    Returns a list of (Node, matched_snippet) tuples, best matches first.
    """
    terms = [t.lower() for t in re.findall(r"[a-z0-9]+", query.lower()) if len(t) > 2]
    if not terms:
        return []

    scored = []
    for node in nodes.values():
        haystack = f"{node.title}\n{node.body_full}".lower()
        hits = sum(haystack.count(t) for t in terms)
        matched_all = all(t in haystack for t in terms)
        if hits == 0:
            continue
        score = hits * (3 if matched_all else 1)
        # snippet: first line containing any term, for the citation
        snippet = ""
        for line in node.body_full.splitlines():
            low = line.lower()
            if any(t in low for t in terms):
                snippet = line.strip()[:220]
                break
        scored.append((score, node, snippet))

    scored.sort(key=lambda x: -x[0])
    return [(n, s) for _, n, s in scored[:limit]]
