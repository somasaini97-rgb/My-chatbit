"""
llm.py — stdlib-only OpenAI client (urllib, no `requests`/`openai` package)
plus a minimal .env parser. Keeps the "no framework, no package manager"
rule intact even for the model call.
"""
import json
import os
import urllib.request
import urllib.error

MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
API_URL = "https://api.openai.com/v1/chat/completions"


def load_dotenv(path):
    """Tiny .env parser — KEY=VALUE per line, # comments, no quoting rules."""
    if not os.path.isfile(path):
        return
    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip()
            if key and key not in os.environ:
                os.environ[key] = value


def api_key_present():
    return bool(os.environ.get("OPENAI_API_KEY"))


def chat(messages, tools=None, tool_choice="auto", timeout=30):
    """
    Minimal OpenAI chat.completions call. Raises on any failure — callers
    are expected to catch and fall back to keyword routing (never fail
    silently, per the build spec).
    """
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY not set")

    body = {"model": MODEL, "messages": messages}
    if tools:
        body["tools"] = tools
        body["tool_choice"] = tool_choice

    req = urllib.request.Request(
        API_URL,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"OpenAI API error {e.code}: {detail[:300]}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Couldn't reach OpenAI: {e.reason}")

    return data["choices"][0]["message"]


def simple_text(prompt, timeout=30):
    """Used by tools.research_web — a single-turn, no-tools call."""
    msg = chat([{"role": "user", "content": prompt}], timeout=timeout)
    return msg.get("content") or ""
